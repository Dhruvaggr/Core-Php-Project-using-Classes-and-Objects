    <?php

$dbhost = "localhost";
$dbpass = "";
$dbname = "usermanagement";
$dbusername = "root";

$db = new mysqli($dbhost,$dbusername, $dbpass ,$dbname);

if($db->connect_error)
{
    die("Connection error:". $db->connect_error);   

}
else{

   // echo "Successful Connection";
 
}


?>