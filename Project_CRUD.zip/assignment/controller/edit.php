<?php
include "../config/database.php";
 //echo"Edit";
 $id = $_GET['id'];
 echo $id;
 $query = "SELECT * from userdata WHERE id= '".$id."'" ;
 $result = mysqli_query($db,$query);
 if($result)
 {
    $array = mysqli_fetch_assoc($result);
    echo"<pre>";
    print_r($array);
    function redirect($url) 
    {
   
        header("Location: ".$url);
        exit();
    }
    redirect("../view/editform.php?data=".urlencode(json_encode($array)));


 }
 else{
    echo "Error";
 }
 
 

?>