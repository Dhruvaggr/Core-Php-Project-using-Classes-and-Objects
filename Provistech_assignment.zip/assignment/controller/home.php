<?php
error_reporting();

class Home{


   public function index($formdata)
   {
                  include "../config/database.php";
                //   echo"<pre>";
                //   print_r($formdata);
                  
              
                    $name = $formdata['Fname'];
                    $email = $formdata['email'];
                    $phoneno = $formdata['phn'];
                    $dp = $formdata['upload']['name'];
                    
                 
                    
                    if( empty($name) || empty($email) || empty($phoneno) || empty($dp))
                    {
                
                        ?>
                        <script>
                        alert ("Please Fill all Parameters");
                        window.location.href = "../view/form.php";
                        </script>

                        <?php
                    }
                  elseif(!empty($email) || !empty($dp))
                    {      



                            $query = "SELECT * from userdata where email='$email'";
                            $result = mysqli_query($db,$query);
                            $num_rows = $result->num_rows;
                            if ($num_rows>0)
                            {
                                ?>
                                <script>
                                    alert("Email Already Exists.");
                                    window.location.href = "../view/form.php";

                                    </script>
                                <?php
                            }
                            else{

                                 if(($formdata['upload']['type']=='image/jpeg')||  ($formdata['upload']['type']=='image/jpg'))
                                         {
                                            $data = array(
                                                'name'=>$name,
                                                'email'=>$email,
                                                'phoneno'=>$phoneno,
                                                'profilephoto'=>$dp
                                            );
                                            
                                            include "../model/user.php";
                                            $usermodel = new User();
                                            $insert = $usermodel->insert($data);
                                         }
                                  else{

                                        ?>
                                           <script>
                                               alert("JPEG and JPG image format only.");
                                               window.location.href = "../view/form.php";
                                            </script>
                                        <?php
                                  }

                            }
                    }

                
                   

    }
    public function getdata()
    {
        $usermodel = new User();
        $data = $usermodel->get();
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Fetched Data</title>
            <link rel="stylesheet" href="../css/bootstrap.css">
        </head>
        <body>

        <div class="panel-heading text-center">

        <h1> User Details </h1>
        </div>
        <div class="panel-heading text-right">
        <a href="../view/form.php" class="btn btn-success">Add Records</a>

        </div>
        <div class="table-responsive">
        <table class="table table-striped">
        <thead class="thead-dark">
            <tr>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Contact</th>
                <th scope="col">Profile Photo</th>
                <th scope="col">Created_at </th>
                <th scope="col">Updated_at </th>
                <th scope="col">Edit</th>
                <th scope="col">Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($data as $row): ?>
                <tr>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo $row['phoneno']; ?></td>
                    <td><?php echo $row['profilephoto']; ?></td>
                    <td><?php echo $row['created_at']; ?></td>
                    <td><?php echo $row['updated_at']; ?></td>

            
                    <td><a href="edit.php?id=<?php echo $row['id']; ?>" class="btn btn-success">Edit</a></td>
                    <td><button type="button" class="btn btn-warning" onclick="confirmDelete(<?php echo $row['id']; ?>)">Delete</button></td>
                </tr>
                
            <?php endforeach; ?>
        </tbody>
        </table>
            </div>
        </body>
        </html>
        <script>
        function confirmDelete(userId) {
            if (confirm("Are you sure you want to delete this user?")) {
                // Redirect to the delete page with the user ID
                window.location.href = "delete.php?id=" + userId;
            }
        }
        </script>

      <?php
       
    }

    


}

 if($_SERVER['REQUEST_METHOD']==='POST')
 {

    
   $_POST['upload'] = $_FILES['upload'];
  
  
    $form=new Home();
   // $form->validation($_POST);
    $form->index($_POST);
    $form->getdata();

 }


 ?>