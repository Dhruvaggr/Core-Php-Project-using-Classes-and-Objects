<?php
 if(isset($_GET['data']))
 {
    $array = json_decode(urldecode($_GET['data']),true);
    $name =   $array['name'];
    $dp =    $array['profilephoto'];
    $email =   $array['email'];
    $phn =   $array['phoneno'];
    
    

    $id = $array['id'];
    
    
  ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management</title>
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
</head>
<body>
    <div class="container">
       <div class="row col-md-6 col-md-offset-3">
              <div class="panel panel-primary">
                       <div class="panel-heading text-center">
                            <h1> Registration Form </h1>
                       </div>  

                       <div class="panel-body">
                            <form action="../model/User.php" method="GET">
                                <div class="form-group">
                                  <input type="hidden" name="id" value="<?php echo $id; ?>">

                                 <label for="name"> Name </label>
                                 <input type="text" class="form-control"  value="<?php echo $name ?>" name="Fname" id="name" />
                                </div>
                                <div class="form-group">
                                 <label for="email"> Email </label>
                                 <input type="email" class="form-control" value="<?php echo $email ?>" name="email" id="email" />
                                </div>
                                <div class="form-group">
                                 <label for="phone_no"> Phone No </label>
                                 <input type="text" class="form-control" value="<?php echo $phn ?>" name="phn" id="phone_no" />
                                </div>
                                <div class="form-group">
                                 <label for="upload_dp"> Profile photo </label>
                                 <input type="file" class="form-control" value = "<?php echo $dp ?>" name="upload" id="upload_dp" />
                                </div>
                                <input type="submit" class="btn btn-primary" value="Update"> 
                                <!-- <button type="button" class="btn btn-warning" onclick="confirmUpdate(<?php echo $id ?>)">Update</button> -->



                            </form>
                       </div>  

                       <div class="panel-footer text-right">
                           <small>  &copy; User Management </small>
                       </div>  

              </div>
            
       </div>
          
    </div>

    
</body>
</html>
    
<?php

 }
?>